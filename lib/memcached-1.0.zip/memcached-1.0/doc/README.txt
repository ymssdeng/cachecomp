WARNING!

This version is not compatible with versions prior to version 0.9.2
Please see javadocs for examples on how to use.

This release required Java 5 in order to work.  If you would like to downport to 1.4
please feel free.
